﻿using System;

namespace WSUniversalLib
{
    public class Calculation
    {
        public int GetQuantityForProduct()
        {
            int productType;
            int materialType;
            int count;
            float width;
            float length;

            // код здесь

            return 0; // заменить на count
        }

    }
}
