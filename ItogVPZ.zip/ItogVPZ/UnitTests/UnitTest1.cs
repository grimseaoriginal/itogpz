﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using System;
using WSUniversalLib1;

namespace UnitTests
{
    [TestFixture]
    public class ProductionCalculatorTests
    {
        private Calculation _calculator;

        [SetUp]
        public void SetUp()
        {
            _calculator = new Calculation();
        }

        [Test]
        public void CalculateRawMaterial_ReturnsCorrectValue_WhenValidArgumentsArePassed()
        {
            // Arrange
            int count = 10;
            int width = 5;
            int length = 10;
            string productType = "1";
            string materialType = "1";

            // Act
            double result = _calculator.CalculateRawMaterial(count, width, length, productType, materialType);

            // Assert
            Assert.AreEqual(605.0, result);
        }

        [Test]
        public void CalculateRawMaterial_ThrowsArgumentException_WhenInvalidProductTypeIsPassed()
        {
            // Arrange
            int count = 10;
            int width = 5;
            int length = 10;
            string productType = "4";
            string materialType = "1";

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _calculator.CalculateRawMaterial(count, width, length, productType, materialType));
        }

        [Test]
        public void CalculateRawMaterial_ThrowsArgumentException_WhenInvalidMaterialTypeIsPassed()
        {
            // Arrange
            int count = 10;
            int width = 5;
            int length = 10;
            string productType = "1";
            string materialType = "3";

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _calculator.CalculateRawMaterial(count, width, length, productType, materialType));
        }
    }
}
