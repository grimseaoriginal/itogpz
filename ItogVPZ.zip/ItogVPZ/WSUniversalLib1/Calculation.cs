﻿using System;

namespace WSUniversalLib1
{
    public class Calculation
    {
        public double CalculateRawMaterial(int count, int width, int length, string productType, string materialType)
        {
            double area = width * length;
            double qualityCoefficient = GetQualityCoefficient(productType);
            double wastePercentage = GetWastePercentage(materialType);
            double totalArea = area * count;
            double requiredArea = totalArea / (1 - wastePercentage);
            double rawMaterial = requiredArea * qualityCoefficient;
            return rawMaterial;
        }

        private double GetQualityCoefficient(string productType)
        {
            switch (productType)
            {
                case "1":
                    return 1.1;
                case "2":
                    return 2.5;
                case "3":
                    return 8.43;
                default:
                    throw new ArgumentException("Неправильный коэффициент типа продукта");
            }
        }

        private double GetWastePercentage(string materialType)
        {
            switch (materialType)
            {
                case "1":
                    return 0.003;
                case "2":
                    return 0.0012;  
                default:
                    throw new ArgumentException("Неправильный тип материала");
            }
        }
    }
}
