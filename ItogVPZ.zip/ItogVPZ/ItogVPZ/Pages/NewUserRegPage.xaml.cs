﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ItogVPZ.Pages
{
    /// <summary>
    /// Логика взаимодействия для NewUserRegPage.xaml
    /// </summary>
    public partial class NewUserRegPage : Page
    {
        public NewUserRegPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(TextBoxLogin.Text) || string.IsNullOrEmpty(PasswordBox.Password))
            {
                MessageBox.Show("Введите логин и пароль!");
            }
            else
            {
                using (var db = new ItogEntities())
                {
                    var user = db.User
                        .AsNoTracking()
                        .FirstOrDefault(u => u.Login == TextBoxLogin.Text);
                    if (user != null)
                    {
                        MessageBox.Show("Пользователь с таким именем уже зарегистрирован!");
                    }
                    else
                    {
                        db.User.Add(new User { Login = TextBoxLogin.Text, Password = PasswordBox.Password, FIO = FIOBox.Text });
                        db.SaveChanges();
                        MessageBox.Show("Вы успешно зарегистрировались!");
                        NavigationService?.GoBack();
                    }
                }
            }
        }

        private void getBackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.GoBack();
        }
    }
}
