﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace ItogVPZ.Pages
{
    /// <summary>
    /// Логика взаимодействия для MaterialsAvailable.xaml
    /// </summary>
    public partial class MaterialsAvailable : Page
    {
        public MaterialsAvailable()
        {
            InitializeComponent();

            ItogEntities itogEntities = new ItogEntities();
            itogEntities.Materials.Load();

            var currentMaterials = ItogEntities.GetContext().Materials.ToList();
            materialsListView.ItemsSource = currentMaterials;
        }

        private void backToMMButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.GoBack();
        }

        private void SearchMaterials()
        {
            var currentMaterials = ItogEntities.GetContext().Materials.ToList();
            if (searchTextBox.Text != "Введите для поиска" || searchTextBox.Text == "")
            {
                currentMaterials = currentMaterials.Where(p => p.NameOfMaterial.Contains(searchTextBox.Text)).ToList();
            }
            else
            {
                MessageBox.Show("Что-то пошло не так!", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            if (currentMaterials != null)
            {
                materialsListView.ItemsSource = currentMaterials;
            }
            else
            {
                
            }
        }

        private void searchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void findButton_Click(object sender, RoutedEventArgs e)
        {
            SearchMaterials();
        }
    }
}
