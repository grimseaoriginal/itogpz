﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ItogVPZ.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditingPage2.xaml
    /// </summary>
    public partial class EditingPage2 : Page
    {
        public EditingPage2()
        {
            InitializeComponent();
            newName_box.Text = EditingPage.fabrics[0];
            newType_box.Text = EditingPage.fabrics[1];
            price_box.Text = EditingPage.fabrics[2];
            amount_box.Text = EditingPage.fabrics[3];           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var edit = new Materials();
                edit.NameOfMaterial = newName_box.Text;
                edit.Type = newType_box.Text;
                edit.Price = price_box.Text;
                edit.Amount = amount_box.Text;
                using (var db = new ItogEntities())
                {
                    var res = db.Materials.SingleOrDefault(b => b.NameOfMaterial == edit.NameOfMaterial);
                    if (res != null)
                    {
                        res.NameOfMaterial = edit.NameOfMaterial;
                        res.Type = edit.Type;
                        res.Price = edit.Price;
                        res.Amount = edit.Amount;
                        db.SaveChanges();
                        MessageBox.Show("Изменения сохранены!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка изменения данных!" + ex.Message);
            }
        }
    }
}
