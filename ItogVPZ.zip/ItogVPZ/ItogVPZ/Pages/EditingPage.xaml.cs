﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
using ItogVPZ.Pages;

namespace ItogVPZ.Pages
{
    /// <summary>
    /// Логика взаимодействия для EditingPage.xaml
    /// </summary>
    public partial class EditingPage : Page
    {
        public static string[] fabrics = new string[4];
        public EditingPage()
        {
            InitializeComponent();
            ItogEntities tgs = new ItogEntities();
            tgs.Materials.Load();
            materialsDataGrid.ItemsSource = tgs.Materials.Local.ToBindingList();
        }

        private void backToMMButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService?.GoBack();
        }
        private void btn_Click(object sender, RoutedEventArgs e)
        {
            var user = new Materials();
            user = (Materials)((Button)e.Source).DataContext;
            fabrics[0] = user.NameOfMaterial;
            fabrics[1] = user.Type;
            fabrics[2] = user.Price;
            fabrics[3] = user.Amount;
            NavigationService?.Navigate(new EditingPage2());
        }
    }
}
